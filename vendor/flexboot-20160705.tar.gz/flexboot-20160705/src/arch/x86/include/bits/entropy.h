#ifndef _BITS_ENTROPY_H
#define _BITS_ENTROPY_H

/** @file
 *
 * x86-specific entropy API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

#include <ipxe/rtc_entropy.h>

#endif /* _BITS_ENTROPY_H */
