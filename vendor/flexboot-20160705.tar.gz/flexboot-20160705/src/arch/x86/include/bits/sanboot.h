#ifndef _BITS_SANBOOT_H
#define _BITS_SANBOOT_H

/** @file
 *
 * x86-specific sanboot API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

#include <ipxe/bios_sanboot.h>

#endif /* _BITS_SANBOOT_H */
